const http = require('http');

const server = http.createServer((req, res) => {
    res.writeHead(200, { 'Content-Type': 'text/plain; charset=utf-8' });
    res.end('<h1>Hello from 120.26.212.80!</h1><p>Server is reachable on Port 80.</p>');
    console.log(`Request received: ${req.url}`);
});

const PORT = 80;
server.listen(PORT, '0.0.0.0', () => {
    console.log(`Simple Test Server running on port ${PORT}`);
});
